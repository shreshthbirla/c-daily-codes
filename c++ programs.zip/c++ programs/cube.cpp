#include<iostream>
using namespace std;

inline int cube(int n)
{
return  n*n*n;
}
int main()
{
cout << "cube of the value is " << cube(5) << endl;
return 0;
}

