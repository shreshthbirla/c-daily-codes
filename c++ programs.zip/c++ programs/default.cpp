#include<iostream>
using namespace std;
int cubevolume(int l=1, int w=2, int h=3) // 1,2,3 are the default values which is passing to the function
{
 l = l*l;
 w = w*w;
 h = h*h;

return l*w*h;
}

int main()
{
// function without argument
cout<< cubevolume() << endl;

// function with 1 argument
cout<< cubevolume(9) << endl;

// function with 3 argument
cout << cubevolume(1,2,3) << endl;

// function with 2 argument
cout << cubevolume(5,2) << endl;

return 0;
}

