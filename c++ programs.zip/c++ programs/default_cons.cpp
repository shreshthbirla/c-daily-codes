// default constructor
#include<iostream>
using namespace std;
class rectangle
{
    public:
    int length,width,height,area,volume;
    rectangle()  // constructor 
    {
        cout << "enter dimensions of rectangle: "<<endl;
        cout << "length: ";
        cin >>length;
        cout << "width: ";
        cin >> width;
        cout << "height: ";
        cin >> height;
        cout << "constructor called" << endl;
        area = length*width;
        volume = length*width*height;
        cout << "area: " << area << endl;
        cout << "volume: " << volume << endl;

    }
};

int main()
{
    rectangle r1; // object
    //rectangle r2; // object, this will call again to constructor
    return 0;
}


