// parameterised constructor and cpoy constructor
#include<iostream>
using namespace std;
class rectangle
{
    public:
    int length,width,area;
    rectangle(int l, int w) // parameterised contructor
    {
        length = l;
        width = w;
        cout << "parameterised constructor called" << endl;
        area = length*width;
        cout << "area: "<< area <<endl;
    }
    rectangle(rectangle &l) // copy constructor
    {
        length = l.length;
        width = l.width;
        cout <<"copy constructor called"<<endl;
        area = length*width;
        cout << "area: "<< area <<endl;
    }
};

int main()
{
    int l,w;
    cout << "enter dimensions: "<< endl;
    cout << "length: ";
    cin >> l;  // this l will go to rectangle constructor and pass the value of it 
    cout << "width: ";
    cin >> w; //this w will go to rectangle constructor and pass the value of it
    
    rectangle r1(l,w); //object of parameterised constructor
    
    /*objects of copy constructor both should be valid
    rectangle r2(r1);
    //rectangle r2 = r1;
    */
    rectangle r2(r1);
}
